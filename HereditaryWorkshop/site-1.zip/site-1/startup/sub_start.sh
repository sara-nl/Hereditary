#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
echo "WORKSPACE set to $DIR/.."
mkdir -p $DIR/../transfer
export PYTHONPATH=/local/custom:$PYTHONPATH
echo "PYTHONPATH is $PYTHONPATH"

# Memory management configuration
# Opt-in jemalloc preload for PyTorch workloads.
# Enable by setting NVFLARE_ENABLE_JEMALLOC_PRELOAD=true.
if [ "${NVFLARE_ENABLE_JEMALLOC_PRELOAD:-false}" = "true" ]; then
  for JEMALLOC in /usr/lib/x86_64-linux-gnu/libjemalloc.so.2 \
                  /usr/lib64/libjemalloc.so.2 \
                  /usr/local/lib/libjemalloc.so; do
      if [ -f "$JEMALLOC" ]; then
          export LD_PRELOAD="${LD_PRELOAD:+$LD_PRELOAD:}$JEMALLOC"
          export MALLOC_CONF="${MALLOC_CONF:-dirty_decay_ms:5000,muzzy_decay_ms:5000}"
          echo "Using jemalloc: $JEMALLOC"
          break
      fi
  done
fi

# Limit glibc memory arenas to reduce RSS fragmentation (ignored by jemalloc)
# Recommended: MALLOC_ARENA_MAX=2 for clients, MALLOC_ARENA_MAX=4 for servers
export MALLOC_ARENA_MAX=${MALLOC_ARENA_MAX:-4}

while [[ $# -gt 0 ]]
do
  key="$1"
  case $key in
    --verify)
      doVerify=true
    ;;
    --once)
      doOnce=true
    ;;
  esac
  shift
done

SECONDS=0
lst=-400
restart_count=0

start_python() {
  python3 -u -m nvflare.private.fed.app.client.client_train -m $DIR/.. -s fed_client.json --set secure_train=true uid=site-1 org=nvidia config_folder=config
}

start_fl() {
  if [[ $(( $SECONDS - $lst )) -lt 300 ]]; then
    ((restart_count++))
  else
    restart_count=0
  fi
  if [[ $(($SECONDS - $lst )) -lt 300 && $restart_count -ge 5 ]]; then
    echo "System is in trouble and unable to start the task!!!!!"
    rm -f $DIR/../pid.fl $DIR/../shutdown.fl $DIR/../restart.fl $DIR/../daemon_pid.fl
    exit
  fi
  lst=$SECONDS
  (start_python 2>&1 & echo $! >&3 ) 3>$DIR/../pid.fl
  pid=`cat $DIR/../pid.fl`
  echo "new pid ${pid}"
}

stop_fl() {
  if [[ ! -f "$DIR/../pid.fl" ]]; then
    echo "No pid.fl.  No need to kill process."
    return
  fi
  pid=`cat $DIR/../pid.fl`
  sleep 5
  kill -0 ${pid} 2> /dev/null 1>&2
  if [[ $? -ne 0 ]]; then
    echo "Process already terminated"
    return
  fi
  kill -9 $pid
  rm -f $DIR/../pid.fl $DIR/../shutdown.fl $DIR/../restart.fl 2> /dev/null 1>&2
}

if [[ "$doVerify" == "true" ]]; then
  python3 -m nvflare.tool.verify_startup_kits -f $DIR/../ -c $DIR/rootCA.pem
  verification_status=$?
  if [[ $verification_status -ne 0 ]]; then
    echo "verification failed"
    exit 1
  fi
fi

if [[ "$doOnce" == "true" ]]; then
  echo "Start NVFlare directly"
  rm -f $DIR/../pid.fl $DIR/../shutdown.fl $DIR/../restart.fl 2> /dev/null 1>&2
  start_python
  exit $?
fi

if [[ -f "$DIR/../daemon_pid.fl" ]]; then
  dpid=`cat $DIR/../daemon_pid.fl`
  kill -0 ${dpid} 2> /dev/null 1>&2
  if [[ $? -eq 0 ]]; then
    echo "There seems to be one instance, pid=$dpid, running."
    echo "If you are sure it's not the case, please kill process $dpid and then remove daemon_pid.fl in $DIR/.."
    exit
  fi
  rm -f $DIR/../daemon_pid.fl
fi

echo $BASHPID > $DIR/../daemon_pid.fl

while true
do
  sleep 5
  if [[ ! -f "$DIR/../pid.fl" ]]; then
    echo "start fl because of no pid.fl"
    start_fl
    continue
  fi
  pid=`cat $DIR/../pid.fl`
  kill -0 ${pid} 2> /dev/null 1>&2
  if [[ $? -ne 0 ]]; then
    if [[ -f "$DIR/../shutdown.fl" ]]; then
      echo "Gracefully shutdown."
      break
    fi
    echo "start fl because process of ${pid} does not exist"
    start_fl
    continue
  fi
  if [[ -f "$DIR/../shutdown.fl" ]]; then
    echo "About to shutdown."
    stop_fl
    break
  fi
  if [[ -f "$DIR/../restart.fl" ]]; then
    echo "About to restart."
    stop_fl
  fi
done

rm -f $DIR/../pid.fl $DIR/../shutdown.fl $DIR/../restart.fl $DIR/../daemon_pid.fl
